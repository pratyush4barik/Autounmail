from pydantic import BaseModel, Field, str, configDict, UUID, Enum
from datetime import datetime
class EmailMessages(BaseModel):
    access_token: str
    content: str

class MessageRole(str, Enum):
    user = "user"
    assistant = "assistant"
    system = "system"

class FilterMessagesResponse(BaseModel):
    id: UUID
    chat_id: UUID
    role: MessageRole
    content: str
    created_at: datetime

    model_config = configDict(from_attributes=True)